@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.oorsprong.org/websamples.countryinfo", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.oorsprong.websamples;
